
Car Bounding Boxes - v2 2026-09-25 11:53am
==============================

This dataset was exported via roboflow.com on September 25, 2026 at 4:54 AM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 12 images.
Car-bounding-boxes are annotated in YOLOv8 format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


